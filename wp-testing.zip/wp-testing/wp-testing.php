<?php
/**
 * Plugin Name: سنجه‌ها
 * Plugin URI: http://1farakav.con/
 * Description: Helps to create psychological tests.
 * Version: 1.1.2
 * Author:  edit : 1farakav
 * Author URI: http://1farakav.com
 * License: GPL3
 * Text Domain: wp-testing
 * Domain Path: /languages
 */

require_once dirname(__FILE__) . '/src/bootstrap.php';

$WpTesting_Facade = new WpTesting_Facade(new WpTesting_WordPressFacade(__FILE__));
